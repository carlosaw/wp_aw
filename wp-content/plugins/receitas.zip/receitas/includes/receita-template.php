<h3>Opções da Receita</h3>
<ul>
  <li>Ingredientes:   INGREDIENTES_PH</li>
  <li>Tempo da Receita: TEMPO_PH</li>
  <li>Utensílios: UTENSILIOS</li>
  <li>Nível de dificuldade: DIFICULDADE_PH</li>
  <li>Tipo da Receita: TIPO_PH</li>
  <li>Nota da Receita: NOTA_PH  (QT_PH votos)</li>
</ul>

<div id="receita_voto" class="rateit" data-rateit-resetable="false" data-id="RECEITA_ID_PH"></div>

<h3>Modo de Preparo</h3>