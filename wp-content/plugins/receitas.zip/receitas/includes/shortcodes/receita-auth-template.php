<div class="ar_receitas_loginarea">
  <div class="ar_receitas_loginitem">
    <h4>Login</h4>
    <div id="receita_login_aviso"></div>
    <form method="POST" id="receita_login">
      E-mail:<br/>
      <input type="email" name="email" id="login_email" /><br/><br/>

      Senha:<br/>
      <input type="password" name="senha" id="login_senha" /><br/><br/>

      <input type="submit" value="Entrar" id="login_botao"/>
    </form>
  </div>

  <div class="ar_receitas_loginitem SHOW_REG_FORM_PH">
    <h4>Cadastro</h4>
    <div id="receita_cadastro_aviso"></div>
    <form method="POST" id="receita_cadastro">
        Nome:<br/>
        <input type="text" name="name" id="cadastro_name" /><br/><br/>
        
        E-mail:<br/>
        <input type="email" name="email" id="cadastro_email" /><br/><br/>

        Senha:<br/>
        <input type="password" name="senha" id="cadastro_senha" /><br/><br/>

        <input type="submit" value="Cadastrar" id="cadastro_botao"/>
    </form>
  </div>
</div>