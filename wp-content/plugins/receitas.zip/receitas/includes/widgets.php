<?php
function ar_widgets_init() {

  register_widget( 'Ar_receita_Do_Dia_Widget' );

}